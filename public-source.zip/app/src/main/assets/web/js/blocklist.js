/**
 * blocklist.js —— 远程封禁名单（按 GitHub 数字 ID 比对）
 *
 * ── 为什么按 ID 而不是用户名 ──
 * 用户名随时能改，改一次旧的判定就失效了。数字 ID 从注册那刻定死，
 * 改昵称、改头像、改用户名都不变。要比对就得比这个。
 *
 * ── 为什么名单放远程 ──
 * 想加谁减谁不用重新发版，改那份 JSON 就行。
 *
 * ── 一条硬规则：拿不到名单就放行 ──
 * 地址挂了、网络不通、JSON 坏了、超时 —— 任何一种都当成「名单为空」。
 * 绝不能反过来：一次网络故障把全体用户挡在门外是灾难级的，
 * 漏放某一个人只是小损失。两者不对等，所以永远偏向放行。
 *
 * ── 不做隐藏 ──
 * 地址和逻辑都明文摆在这里。混淆只能骗过不读源码的人，
 * 对真正会去看的人毫无作用，却会让这个开源项目多一条「藏着东西」的嫌疑。
 */
window.Blocklist = (function () {
  'use strict';

  /* 名单地址。一份 JSON，形如：
   *   { "ids": [70214970, 12345678] }
   * 换成自己的地址即可，格式不变。 */
  var URL = 'https://raw.githubusercontent.com/Buwrt/githup/main/blocklist.json';

  /* 拿名单最多等这么久。启动路径上不该被一个旁支请求拖住。 */
  var TIMEOUT_MS = 8000;

  var loaded = null;   // 本次会话已拿到的名单，避免重复请求

  /**
   * 拉名单 → 取出里面的 ids 数组。
   * 任何异常都 resolve 成空数组（放行），不往上抛。
   */
  function load() {
    if (loaded) return Promise.resolve(loaded);

    var headers = {
      'Accept': 'application/json',
      'User-Agent': 'githup/1.0'
    };

    /* 走原生通道：页面源是本地的，直接 fetch 是跨域，会被拦掉。
     * 没有原生环境（浏览器里跑着玩）就放弃 —— 拿不到就放行。 */
    var p;
    if (window.Native && typeof window.Native.http === 'function') {
      p = window.Native.http('GET', URL, '', headers)
        .then(function (r) {
          if (!r || r.status !== 200 || !r.body) return [];
          var j = null;
          try { j = JSON.parse(r.body); } catch (e) { return []; }
          var ids = j && j.ids;
          if (!Array.isArray(ids)) return [];
          return ids.map(Number).filter(function (n) { return !isNaN(n); });
        });
    } else {
      p = Promise.resolve([]);
    }

    /* 超时兜底：宁可放行，也不能让启动卡在这上面。 */
    var timer = new Promise(function (res) { setTimeout(function () { res([]); }, TIMEOUT_MS); });

    return Promise.race([p, timer]).then(function (ids) {
      loaded = ids;
      return ids;
    }).catch(function () {
      loaded = [];
      return [];
    });
  }

  return {
    /**
     * 这个数字 ID 在不在名单里。
     * @param {number|string} uid  GitHub 账号数字 ID
     * @returns {Promise<boolean>} 只在确定命中时返回 true
     */
    check: function (uid) {
      var n = Number(uid);
      if (!n || isNaN(n)) return Promise.resolve(false);
      return load().then(function (ids) {
        return ids.indexOf(n) >= 0;
      }).catch(function () { return false; });
    },

    /** 命中后铺一层全屏页，应用不再可用 */
    show: function () {
      var host = document.getElementById('app');
      var splash = document.getElementById('splash');
      if (splash) splash.remove();
      if (!host) return;
      host.hidden = false;
      host.innerHTML =
        '<div class="page" style="display:flex;align-items:center;justify-content:center;min-height:60vh">' +
        '<div class="card" style="padding:24px;text-align:center;max-width:320px">' +
        '<div style="margin-bottom:12px">' + (window.icon ? window.icon('alert', 28) : '') + '</div>' +
        '<div style="font-size:15px;font-weight:600;margin-bottom:8px">无法使用本应用</div>' +
        '<div class="muted" style="font-size:13px;line-height:1.6">' +
        '当前 GitHub 账号已被限制使用 githup。' +
        '</div></div></div>';
    },

    /** 名单地址（方便排查） */
    url: URL
  };
})();
