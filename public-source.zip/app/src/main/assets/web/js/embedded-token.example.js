/* ============================================================
 * embedded-token.example.js — 模板
 *
 * 用法：复制为 embedded-token.js，把 '' 里填上你的 Personal Access Token。
 *
 *   cp js/embedded-token.example.js js/embedded-token.js
 *   然后编辑 embedded-token.js，填入令牌
 *
 * ⚠️ embedded-token.js 已被 .gitignore 排除，不会被提交。
 *    别把真实令牌写进公开仓库 —— GitHub 会自动吊销它。
 *
 * 留空（''）就是普通的「需要登录」模式，一切照旧。
 * ============================================================ */
window.EMBEDDED_TOKEN = '';
